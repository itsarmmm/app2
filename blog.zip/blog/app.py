import config
import logging
from connect import SQLighter
from datetime import datetime, date
import asyncio
import requests
from currency_converter import CurrencyConverter, CryptoConverter
import random
import send_crypto

from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

import django
import os

# os.environ['DJANGO_SETTINGS_MODULE'] = 'blog.settings'
#
# django.setup()


url = "https://v6.exchangerate-api.com/v6/94b6c731282ec76641557886/latest/USD"
# url_amd = "https://v6.exchangerate-api.com/v6/94b6c731282ec76641557886/latest/AMD"
cur = CurrencyConverter(url)
# cur_amd = CurrencyConverter(url_amd)


async def check_time(sleep_for):
    while True:
        await asyncio.sleep(sleep_for)
        now = datetime.now().strftime("%H")
        if now == "09":
            daily_rate = cur.convert()
            today = date.today().strftime("%d/%m/%Y")
            db.add_daily_rate(daily_rate, today)
            break
        else:
            continue



btc_url = "https://api.nomics.com/v1/currencies/ticker?key=b3a9bb4a8b0fc3c9c3218a1707f9d00b5f657328&ids=BTC&interval=1d,30d&convert=USD&per-page=100&page=1"
btc_cur = CryptoConverter(btc_url)

dash_url = "https://api.nomics.com/v1/currencies/ticker?key=b3a9bb4a8b0fc3c9c3218a1707f9d00b5f657328&ids=DASH&interval=1d,30d&convert=USD&per-page=100&page=1"
dash_cur = CryptoConverter(dash_url)


logging.basicConfig(level = logging.INFO)


bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher(bot)

db = SQLighter('db.sqlite3')



@dp.message_handler(commands = ['start'])
async def echo(message: types.Message):
    try:
        if str(db.get_referrer(message.from_user.id)) != "0" and str(db.get_referrer(message.from_user.id)) != message.from_user.id:
            referrer = message.text.split(' ')[1]
            db.set_referrer(message.from_user.id, referrer)
            db.update_partner_status(referrer)
            await bot.send_message(message.from_user.id, f"""Ձեզ հրավիրել է ID{referrer} օգտատերը🙋‍♂️""")
        else:
            pass

    except:
        pass



    try:
        if db.subscriber_exists(message.from_user.id):
            if db.get_status(message.from_user.id) == "Not Complete":
                await bot.send_message(message.from_user.id, """Ձեր գործարքը ընթացքի մեջ է ⏳\nԿատարեք վճարումը և ուղարկեք անդորրագիրը""")
                return
            elif db.get_status(message.from_user.id) == "Pending":
                await bot.send_message(message.from_user.id, """Ձեր անդորրագիրը ստուգվում է, խնդրում ենք սպասել․․․""")
                return
    except:
        pass

    if not db.user_exists(message.from_user.id):
        db.add_subscriber(message.from_user.id)


    inline_kb_full = InlineKeyboardMarkup(row_width=2)

    buy_btc = InlineKeyboardButton('Գնել BTC', callback_data='btn_buy_btc')
    sell_btc = InlineKeyboardButton('Վաճառել BTC', callback_data='btn_sell_btc')
    buy_dash = InlineKeyboardButton('Գնել DASH', callback_data='btn_buy_dash')
    sell_dash = InlineKeyboardButton('Վաճառել DASH', callback_data='btn_sell_dash')
    partner = InlineKeyboardButton('Դառնալ գործընկեր🤵‍♂️', callback_data='get_partner')

    if db.get_partner_status(message.from_user.id) == 1:
        partner = InlineKeyboardButton("Իմ հաշիվը💸", callback_data='partner_balance')

    inline_kb_full.add(buy_btc, sell_btc, buy_dash, sell_dash, partner)

    await message.answer("""👨‍🚀 Ողջույն,
Ընտրե՛ք՝ ի՞նչ գործարք եք ցանկանում կատարել։

*մեր համակարգում կատարված, 12․000 դրամը գերազանցող յուրաքանչյուր 50-րդ գործարք կատարողը կստանա նվեր՝ 50 USD:

*մինչև սեպտեմբերի 20-ը կատարի՛ր 12․000 դրամը գերազանցող 5 հաջողված գործարք և ստացի՛ր նվեր՝ 10 USD: 💵""", reply_markup=inline_kb_full)




@dp.callback_query_handler(lambda c: c.data.startswith('partner'))
async def get_up_partner(callback_query: types.CallbackQuery):
    balance = db.get_partner_balance(callback_query.message.chat.id)
    await bot.send_message(callback_query.message.chat.id, f"""Դուք արդեն գործընկեր եք🤵‍♂️

Ձեր հաշիվը կազմում է՝ {balance} դրամ։ Փոխանցումները կատարվում են ամեն օր՝ ժամը 18։00֊ից 22։00։""")



@dp.callback_query_handler(lambda c: c.data.startswith('get'))
async def get_up_partner(callback_query: types.CallbackQuery):
    await bot.send_message(callback_query.message.chat.id, f"""Շատ լավ 🤗Առաջարկում ենք ձեր վճարումները ստանաք մեր բոտի միջոցով, ստանալ ամեն գործարքից 1% ռեֆերալ բոնուս։

https://t.me/cryptotest20_bot?start={callback_query.message.chat.id}

Սա Ձեր անհատական հղումն է, ուղարկեք այն Ձեր ընկերներին, դրանով գրանցվելու դեպքում՝ դուք կստանաք 1% միջնորդավճար նրանց կատարած գնումներից🥳""")


@dp.callback_query_handler(lambda c: c.data.startswith('btn'))
async def process_callback_kb1btn1(callback_query: types.CallbackQuery):

    try:
        if db.subscriber_exists(callback_query.from_user.id):
            if db.get_status(callback_query.from_user.id) == "Not Complete":
                await bot.send_message(callback_query.message.chat.id, """Ձեր գործարքը ընթացքի մեջ է ⏳\nԿատարեք վճարումը և ուղարկեք անդորրագիրը""")
                return
            elif db.get_status(callback_query.from_user.id) == "Pending":
                await bot.send_message(callback_query.message.chat.id, """Ձեր անդորրագիրը ստուգվում է, խնդրում ենք սպասել․․․""")
                return
    except:
        pass

    rates_kb = InlineKeyboardMarkup(row_width=2)

    amd = InlineKeyboardButton('AMD🇦🇲', callback_data='rate_AMD')
    usd = InlineKeyboardButton('USD🇺🇸', callback_data='rate_USD')

    rates_kb.add(amd, usd)

    code = callback_query.data[4::]
    db.set_order_type(callback_query.from_user.id, code)
    if code == "buy_btc":
        await bot.send_message(callback_query.message.chat.id, text='Ընտրե՛ք արժույթը, որով ցանկանում եք նշել BTC-ի քանակը',  reply_markup=rates_kb)
    if code == "sell_btc":
        await bot.send_message(callback_query.message.chat.id, text='Ընտրե՛ք արժույթը, որով ցանկանում եք նշել BTC-ի քանակը',  reply_markup=rates_kb)
    if code == "buy_dash":
        await bot.send_message(callback_query.message.chat.id, text='Ընտրե՛ք արժույթը, որով ցանկանում եք նշել Dash-ի քանակը',  reply_markup=rates_kb)
    if code == "sell_dash":
        await bot.send_message(callback_query.message.chat.id, text='Ընտրե՛ք արժույթը, որով ցանկանում եք նշել Dash-ի քանակը',  reply_markup=rates_kb)



@dp.callback_query_handler(lambda c: c.data.startswith('rate'))
async def process_callback_rates(callback_query: types.CallbackQuery):

    try:
        if db.subscriber_exists(callback_query.from_user.id):
            if db.get_status(callback_query.from_user.id) == "Not Complete":
                await bot.send_message(callback_query.message.chat.id, """Ձեր գործարքը ընթացքի մեջ է ⏳\nԿատարեք վճարումը և ուղարկեք անդորրագիրը""")
                return
            elif db.get_status(callback_query.from_user.id) == "Pending":
                await bot.send_message(callback_query.message.chat.id, """Ձեր անդորրագիրը ստուգվում է, խնդրում ենք սպասել․․․""")
                return
    except:
        pass


    code = callback_query.data[5::]

    try:
        order_type = str(db.get_order_type(callback_query.message.chat.id))
    except:
        pass

    db.set_currency(callback_query.message.chat.id, code)


    if order_type == "buy_btc":
        await bot.send_message(callback_query.message.chat.id, text=f'Որքա՞ն {code}-ի համարժեք BTC եք ցանկանում գնել')
        db.set_crypto_currency(callback_query.message.chat.id, "BTC")
    elif order_type == "sell_btc":
        await bot.send_message(callback_query.message.chat.id, text=f'Որքա՞ն {code}-ի համարժեք BTC եք ցանկանում վաճառել')
        db.set_crypto_currency(callback_query.message.chat.id, "BTC")
    elif order_type == "buy_dash":
        await bot.send_message(callback_query.message.chat.id, text=f'Որքա՞ն {code}-ի համարժեք DASH եք ցանկանում գնել')
        db.set_crypto_currency(callback_query.message.chat.id, "DASH")
    elif order_type == "sell_dash":
        await bot.send_message(callback_query.message.chat.id, text=f'Որքա՞ն {code}-ի համարժեք DASH եք ցանկանում վաճառել')
        db.set_crypto_currency(callback_query.message.chat.id, "DASH")



@dp.message_handler(lambda message: len(message.text) < 7)
async def process_payment(message: types.Message):

    try:
        if db.subscriber_exists(message.from_user.id):
            if db.get_status(message.from_user.id) == "Not Complete":
                await bot.send_message(message.from_user.id, """Ձեր գործարքը ընթացքի մեջ է ⏳\nԿատարեք վճարումը և ուղարկեք անդորրագիրը""")
                return
            elif db.get_status(message.from_user.id) == "Pending":
                await bot.send_message(message.from_user.id, """Ձեր անդորրագիրը ստուգվում է, խնդրում ենք սպասել․․․""")
                return
    except:
        pass


    currency = db.get_currency(message.chat.id)

    if currency == "USD":
        from_c, to_c = "USD", "AMD"
        min, max = 5, 1000
    else:
        from_c, to_c = "AMD", "USD"
        min, max = 2500, 500_000


    if message.text.isdigit():
        if int(message.text) >= min and int(message.text) <= max:

            db.set_price(message.chat.id, int(message.text))
            payment_kb = InlineKeyboardMarkup(row_width=1)

            meth_idram = InlineKeyboardButton('idram', callback_data='meth_idram')
            meth_telcell = InlineKeyboardButton('Telcell', callback_data='meth_telcell')
            meth_easypay = InlineKeyboardButton('Easypay', callback_data='meth_easypay')

            payment_kb.add(meth_idram, meth_telcell, meth_easypay)

            if db.get_order_type(message.chat.id).startswith("buy"):
                await message.answer("Ընտրե՛ք վճարման մեթոդը։", reply_markup=payment_kb)
            else:
                await message.answer("Ընտրեք վճարումը ստանալու մեթոդը։", reply_markup=payment_kb)

        else:
            await message.answer(f"""Գործարքի նվազագույն գումարը կազմում է {min} {currency}, առավելագույնը՝ {max} {currency}""")

    else:
        await message.answer("Մուտքագրեք միայն թիվը, առանց նշանների")



@dp.callback_query_handler(lambda c: c.data.startswith('meth'))
async def process_callback_payment(callback_query: types.CallbackQuery):

    try:
        if db.subscriber_exists(callback_query.from_user.id):
            if db.get_status(callback_query.from_user.id) == "Not Complete":
                await bot.send_message(callback_query.message.chat.id, """Ձեր գործարքը ընթացքի մեջ է ⏳\nԿատարեք վճարումը և ուղարկեք անդորրագիրը""")
                return
            elif db.get_status(callback_query.from_user.id) == "Pending":
                await bot.send_message(callback_query.message.chat.id, """Ձեր անդորրագիրը ստուգվում է, խնդրում ենք սպասել․․․""")
                return
    except:
        pass

    meth = callback_query.data[5::]

    db.set_method(callback_query.message.chat.id, meth)

    db.add_order(callback_query.message.chat.id)

    last = str(db.get_last_orderId())

    orderId = str(random.randint(100,999)) + last[::-1] + str(random.randint(100,999))

    crypto_currency = db.get_crypto_currency(callback_query.message.chat.id)
    price = db.get_price(callback_query.message.chat.id)
    currency = db.get_currency(callback_query.message.chat.id)

    converted_price = price
    rate = int(db.get_rate()) + 5

    pay_price = price * rate
    pay_price = cur.add_commission(pay_price)

    if currency == "AMD":
        # converted_price = cur.clean_convert(price)
        print(price)
        pay_price = cur.add_commission(price)

    if crypto_currency == "BTC":
        crypto_price = btc_cur.crypto_convert(price)
        crypto_rate = btc_cur.get_crypto_rate()
        db.set_crypto_rate(callback_query.message.chat.id, crypto_rate)

        if currency == "AMD":
            crypto_price = crypto_price / rate
        crypto_price = round(crypto_price, 8)

    else:
        crypto_price = dash_cur.crypto_convert(price)
        crypto_rate = dash_cur.get_crypto_rate()
        db.set_crypto_rate(callback_query.message.chat.id, crypto_rate)

        if currency == "AMD":
            crypto_price = crypto_price / rate
        crypto_price = round(crypto_price, 8)

    db.set_crypto_price(callback_query.message.chat.id, crypto_price)



    if db.get_method(callback_query.message.chat.id) == "idram":
        wallet = config.IDRAM_WALLET
        pay_system = "idram"
    elif db.get_method(callback_query.message.chat.id) == "telcell":
        wallet = config.TELCELL_WALLET
        pay_system = "Telcell"
    else:
        wallet = config.EASYPAY_WALLET
        pay_system = "Easypay"




    if db.get_order_type(callback_query.message.chat.id).startswith("buy"):
        await bot.send_message(callback_query.message.chat.id, text=f"Գործարքի #: {orderId} \nԳործարքի տեսակ: Գնում \nԳումարի չափ: {price} {currency} \nՁեզ կփոխանցվի: {crypto_price} {crypto_currency}")
        await bot.send_message(callback_query.message.chat.id, text = f"Փոխանցեք և ուղարկեք ինձ անդորրագրի համարը 📸\n\n{pay_price} Դ ➡️ {wallet} {pay_system}\n\nԴուք ունեք 30 րոպե գործարքը կատարելու համար\nԽնդիրների դեպքում կապվեք` @itsarmmm\n\nԳործարքը չեղարկելու համար /cancel")
        print(pay_price)
        db.set_pay_price(callback_query.message.chat.id, pay_price)

    else:
        rate = rate - 5
        pay_price = price * rate
        if currency == "AMD":
            # converted_price = cur.clean_convert(price)
            pay_price = price

        db.set_pay_price(callback_query.message.chat.id, pay_price)

        wallet = config.DASH_WALLET

        if crypto_currency == "BTC":
            wallet = config.BTC_WALLET



        await bot.send_message(callback_query.message.chat.id, text=f"Գործարքի #: {orderId} \nԳործարքի տեսակ: Վաճառք \nԳումարի չափ: {price} {currency} \nՁեզ կփոխանցվի: {pay_price} Դ")
        await bot.send_message(callback_query.message.chat.id, text = f"Փոխանցեք և ուղարկեք ինձ անդորրագրի համարը 📸\n\n{crypto_price} {crypto_currency} ⬇️ \n{wallet}\n\nԴուք ունեք 30 րոպե գործարքը կատարելու համար\nԽնդիրների դեպքում կապվեք` @itsarmmm\n\nԳործարքը չեղարկելու համար /cancel")

    order_data = []
    order_data.append(db.get_all(callback_query.message.chat.id))
    order_data = order_data[0][0]

    print(order_data)

    db.create_order(order_data[1],order_data[3][:4],str(order_data[9]) + " դրամ", order_data[6],order_data[7], order_data[12], order_data[13], datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


@dp.message_handler(commands = ['cancel'])
async def cancel(message: types.Message):
    try:
        db.delete_order(message.from_user.id)
        await message.answer("❌ Գործարքը չեղարկված է\n\nՆոր գործարք սկսելու համար /start")
    except:
        await message.answer("Դուք դեռ չունեք ակտիվ գործարք\n\nՆոր գործարք սկսելու համար /start")

@dp.message_handler(content_types=["photo"])
async def check_payment(message: types.Message):
    await message.photo[-1].download(f'main/static/main/img/receipts/{db.get_current_order(message.from_user.id)}.jpg')

    db.set_receipt(message.from_user.id, f'receipts/{db.get_current_order(message.from_user.id)}.jpg')
    db.set_status(message.from_user.id, "Pending")
    await message.answer(f"Կատարվում է ստուգում, խնդրում ենք սպասել․․․🔄")
    user_id = message.from_user.id
    loop = asyncio.get_event_loop()
    loop.create_task(periodic(10,user_id))



async def periodic(sleep_for, user_id):
    # user_id = db.get_last_client()
    while True:
        await asyncio.sleep(sleep_for)
        try:
            if db.get_status(user_id) == "Completed":
                try:
                    referral_amount = round(int(db.get_pay_price(user_id)) / 100)
                    db.add_partner_balance(user_id, referral_amount)
                except:
                    pass
                await bot.send_message(user_id, "Ամեն ինչ ճիշտ է։ Ուղարկեք Ջեր հաշվեհամարը")
                break
            elif db.get_status(user_id) == "Canceled":
                await bot.send_message(user_id, "Ինչ որ բան այն չէ")
                break
            else:
                pass
        except:
            pass




@dp.message_handler(lambda message: message.text[0] == "X" and len(message.text) == 32)
async def process_send_crypto(message: types.Message):
    await bot.send_message(message.from_user.id, f"""Dash""")



@dp.message_handler(lambda message: len(message.text) > 10)
async def process_send_crypto(message: types.Message):
    try:
        if db.subscriber_exists(message.from_user.id):
            if db.get_status(message.from_user.id) == "Completed":
                send_price = float(db.get_crypto_price(message.from_user.id))
                send(config.BTC_PRIVATE_KEY, str(message.text), send_price, 400)
# # mohjSavDdQYHRYXcS3uS6ttaHP8amyvX78
                print(get_tr(config.BTC_PRIVATE_KEY))
                await bot.send_message(message.from_user.id, f"""Կրիպտոն ուղարկված է Ձեր դրամապանակին։ Շնորհակալություն մեր ծառայություններից օգտվելու համար։""")

    except:
        await bot.send_message(message.from_user.id, """Տեղի է ունեցել սխալ։
Խնդրում ենք կապնվել օպերատորի հետ՝ @itsarmmm:""")





if __name__ == "__main__":
    loop2 = asyncio.get_event_loop()
    loop2.create_task(check_time(3600))
    executor.start_polling(dp)
