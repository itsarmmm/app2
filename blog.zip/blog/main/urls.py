from django.urls import path
from . import views



urlpatterns = [
    path('', views.index, name = 'home'),
    path('orders', views.orders, name = 'orders'),
    path('pending_orders', views.pending_orders, name = 'pending_orders'),
    path('partners', views.partners, name = 'partners')

]
