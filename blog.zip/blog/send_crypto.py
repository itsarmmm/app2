from bit import PrivateKey as Key


def send(mk, wallet, money, fee):
	try:
		k = Key(mk)
		print(k.get_balance("usd"))
		outputs = [(wallet, money, "btc")]
		k.send(outputs, fee = fee)
	except Exception as e:
		print(e)

def get_tr(mk):
	k = Key(mk)
	transactions = k.get_transactions()
	print(transactions)


# send("5JFHoWfwirphigZkGw1uAigBYtNuErVodw21hfghSd2PJj7RaXo", "bc1q02g5wtgpxpmq3uye8ch30j6fql8n2m5tvs96jz", 0.0001, 10000)


# get_tr("5JFHoWfwirphigZkGw1uAigBYtNuErVodw21hfghSd2PJj7RaXo")
